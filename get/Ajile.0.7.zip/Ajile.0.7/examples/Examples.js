/**----------------------------------------------------------------------------+
| Product:  Examples.js - Ajile's Examples auto-loader; demonstrates MVC support.
|+-----------------------------------------------------------------------------+
| Author:   Michael A. I. Lee [ajile@iskitz.com]
|
| Created:  Friday,    November   2, 2006    [2006.06.02 - 19:44:40 EDT]
| Modified: Thursday   September 28, 2006    [2006.09.28 - 06:21:45 EDT]
|+-----------------------------------------------------------------------------+
| 
| This file is an example of how to use Ajile's automatic Model View Control
| (MVC) support feature. This feature makes it possible to create a single point
| of control for all scripting logic and to separate that logic from the page,
| site or application's display logic.
|
| Simply create a .js file with the exact name as your view file (*.htm, *.jsp,
| *.asp, *.php, *.xml, other (X)HTML generating file).
|
| Ajile will automatically load the .js file whenever the view file is loaded,
| provided that the view page loads Ajile.
|
| This file can contain any type of JavaScript functionality needed to support
| the view or anything else. It will be the very first module loaded by Ajile.
|
| If your page will accessed as a default page (no filename specified), i.e:
|
|  http://ajile.iskitz.com/   loads    http://ajile.iskitz.com/index.htm
|
| Ajile will automatically load the index.js auto-loader file in your .htm
| file's directory. This will be the behavior for any page thatis accessed via
| the defaut page method. So for example even if you're using IIS with a setup
| where:
|
|  http://ajile.iskitz.com/   loads    http://ajile.iskitz.com/default.htm
|
| your page's auto-loader must still be named "index.js" NOT default.js. This
| requirement exists because there is no standard client-side JavaScript
| approach to determining your page's actual name whn it's loaded as a default
| page.
|
| When used within web pages (e.g. HTML, XHTML, HTA, JSP, ASP, PHP, CGI, etc.)
| the only SCRIPT tag required is one that loads the Ajile module. For example:
| 
| &lt;script type="text/javascript" src="__Ajile's_Path__" &gt;&lt;/script&gt;
|
| [ Ajile 0.6 :: http://ajile.iskitz.com/ :: "Smart scripts that play nice!" ]
|+----------------------------------------------------------------------------*/

//Ajile.EnableCloaking(false);
//Ajile.EnableDebug(false);
Ajile.EnableOverride();

Namespace ("com.iskitz.ajile");

Import ("com.iskitz.ajile.examples.*.0.6", "scripts/");
Import ("com.iskitz.ajile.examples.ImportModule.*");


com.iskitz.ajile.Examples = new function()
{
   var areImportsReady = false;
   var moduleName      = "com.iskitz.ajile.Examples";
   window.onunload     = $Destroy;

   Ajile.AddImportListener(genericImportListener);
   Ajile.AddImportListener(moduleName, $Create);
   Import(moduleName);

   function $Create()
   {
      Ajile.RemoveImportListener(moduleName, $Create);
      //Ajile.ShowLog();
   }
   
   function $Destroy()
   {
      //Ajile.ShowLog();
      if(Ajile && Ajile.Unload)
         Ajile.Unload();
   }

   function genericImportListener(moduleName)
   {
      if(  "undefined" == typeof(AComplex)
        || "undefined" == typeof(Complex)
        || "undefined" == typeof(ImportFunction)
        || "undefined" == typeof(showContents)
        || "undefined" == typeof(com.iskitz.ajile.examples.LoadExample))
         return;

      areImportsReady = true;
      Ajile.RemoveImportListener(genericImportListener);
   }

   this.testAmbiguity = function testAmbiguity()
   {
      if(typeof Complex == "undefined" || typeof AComplex == "undefined")
      {
         alert( "Ambiguity test was unsuccessful :-(\n\n"
              + "Failed to import both [ com.iskitz.ajile.examples.Complex ]\n"
              + "and [ com.iskitz.ajile.examples.ambiguous.Complex ]");

         return;
      }

      var complex = new Complex();
      complex.sayHello();

      var aComplex = new AComplex();
      aComplex.sayHello();
   };

   this.testDependency = function testDependency()
   {
      if(typeof Complex == "undefined")
      {
         alert( "Dependency test was unsuccessful :-(\n\n"
              + "Failed to Import [ com.iskitz.ajile.examples.Complex ]");

         return;
      }

      var complex = new Complex();
      complex.sayHello();
   };

   this.testImport = function testImport()
   {
      if(typeof ImportFunction != "undefined")
         ImportFunction();
      else
         alert( "Import test was unsuccessful :-(\n\n"
              + "Failed to Import [ com.iskitz.ajile.examples.ImportFunction ]");
   };

   this.testImportListener = function testImportListener(moduleName)
   {
      var status = areImportsReady ? ' ' : " NOT ";

      alert( "Import Listener test was"+ status +"successful!\n\n"
           + "All required modules have"+ status +"been imported.");
   };

   this.testImportModule = function testImportModule()
   {
      var imported = (typeof showContents != "undefined");

      if(imported)
         if("undefined" != typeof(com.iskitz.ajile.examples.ImportModule))
            if(showContents == com.iskitz.ajile.examples.ImportModule.showContents)
               imported = true;
      
      if(imported) showContents();

      else alert( "ImportModule test was unsuccessful :-(\n\n Failed to "
                + "Import [ com.iskitz.ajile.examples.ImportModule.* ]");
   };

   this.testLoad = function testLoad()
   {
      if(typeof com.iskitz.ajile.examples.LoadExample != "undefined")
         com.iskitz.ajile.examples.LoadExample();
      else
         alert( "Load test was unsuccessful :-(\n\n"
              + "Failed to Load [ com.iskitz.ajile.examples.LoadExample.js ]");
   };

   this.testNamespace = function testNamespace()
   {
      // create com.iskitz.ajile.examples namespace
      Namespace ("com.iskitz.ajile.examples");

      var msg = "Failed to create";

      if(com != undefined)
         if(com.iskitz != undefined)
            if(com.iskitz.ajile != undefined)
               if(com.iskitz.ajile.examples != undefined)
                  msg = "Successfully created";

      alert(msg + " the [ com.iskitz.ajile.examples ] namespace!");
   };
};