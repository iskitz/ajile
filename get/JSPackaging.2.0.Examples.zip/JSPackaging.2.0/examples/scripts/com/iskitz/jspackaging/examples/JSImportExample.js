JSPackage ("com.iskitz.jspackaging.examples");

com.iskitz.jspackaging.examples.JSImportExample = function ()
{
   alert("JSImportExample was successfully imported!");
};