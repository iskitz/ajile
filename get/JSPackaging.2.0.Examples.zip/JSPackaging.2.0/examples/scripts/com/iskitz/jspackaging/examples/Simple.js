JSPackage ("com.iskitz.jspackaging.examples");

com.iskitz.jspackaging.examples.Simple = function()
{
	this.toString = function toString()
	{
		return "[Simple]";
	};
};