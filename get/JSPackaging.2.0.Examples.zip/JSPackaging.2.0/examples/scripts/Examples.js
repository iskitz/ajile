window.onload = function ()
{
   // Reset base path to "scripts" instead of JSPackaging's "scripts/packed"
   JSBasePath ("scripts");

   JSImport ("com.iskitz.jspackaging.examples.JSImportExample");
   JSImport ("com.iskitz.jspackaging.examples.Complex");
   JSLoad ("scripts/com/iskitz/jspackaging/examples/JSLoadExample.js");
};

function testJSImport()
{
   if(typeof JSImportExample != "undefined")
      JSImportExample();
   else
      alert("com.iskitz.jspackaging.examples.JSImportExample\n"
            + "was NOT successfully imported");
   
   return false;
}

function testJSLoad()
{
   if(typeof isJSLoaded != "undefined")
      isJSLoaded();
   else
   {
      alert("Failed to load com/iskitz/jspackaging/examples/JSLoadExample.js "
            + "external JavaScript file!");
   }
   
   return false;
}

function testJSPackage()
{
   // create com.iskitz.jspackaging.examples package
   JSPackage ("com.iskitz.jspackaging.examples");
      
   var status = "NOT";

   if(com != undefined)
      if(com.iskitz != undefined)
         if(com.iskitz.jspackaging != undefined)
            if(com.iskitz.jspackaging.examples != undefined)
               status = "successfully";

   alert("The com.iskitz.jspackaging.examples package\n"
         + "was [ " + status + " ] created!");
   
   return false;
}
   
function testPackageDependency()
{
   var complex = new Complex();
   complex.sayHello();
   
   return false;
}
