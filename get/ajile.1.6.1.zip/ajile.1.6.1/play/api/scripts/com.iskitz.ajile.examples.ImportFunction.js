Namespace ("com.iskitz.ajile.examples");

com.iskitz.ajile.examples.ImportFunction = function ImportFunction ()
{
   alert("Successfully imported [ com.iskitz.ajile.examples.ImportFunction ]!");
};
