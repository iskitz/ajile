/*
 About   : ajile's Load Tests Support.
 Author  : Michael Lee (iskitz.com)
 Created : 2011.12.17 @ 11:34 PM PT
 Updated : 2012.05.25 @ 11:44 PM PDT
 */

Namespace ("net.ajile.test.Load.external");

net.ajile.test.Load.external.works = true;

