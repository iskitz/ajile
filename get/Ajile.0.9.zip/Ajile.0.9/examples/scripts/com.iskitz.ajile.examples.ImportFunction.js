Namespace ("com.iskitz.ajile.examples");

com.iskitz.ajile.examples.ImportFunction = function()
{
   alert("Successfully imported [ com.iskitz.ajile.examples.ImportFunction ]!");
};
