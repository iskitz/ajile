/* Non-Versioned com.iskitz.ajile.examples namespace loader. */

Namespace ("com.iskitz.ajile.examples");

Import    ("com.iskitz.ajile.examples.Complex");
Import    ("com.iskitz.ajile.examples.ImportFunction");
Load      ("scripts/com.iskitz.ajile.examples.LoadExample.js");
ImportAs  ("AComplex", "com.iskitz.ajile.examples.ambiguous.Complex");