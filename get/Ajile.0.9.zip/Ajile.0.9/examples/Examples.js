/**----------------------------------------------------------------------------+
| Product:  Examples.js - Ajile's per-page module for the Examples page.      |
|+-----------------------------------------------------------------------------+
| Author:   Michael A. I. Lee [ http://ajile.iskitz.com/ ]
|
| Created:  Friday,    November   2, 2006    [2006.06.02 - 07:44:40 PM EDT]
| Modified: Tuesday,   July      24, 2007    [2007.07.24 - 06:12:00 AM EDT]
|+-----------------------------------------------------------------------------+
|
|   [ Ajile :: http://ajile.iskitz.com/ :: "Smart scripts that play nice!" ]
| 
| This file demonstrates the use of Ajile's automatic Model View Controller
| (MVC) support feature. This feature makes it possible to separate a page's
| presentation ((X)HTML) and behavioral (JS) layers by creating a single point
| of control for all of a page's scripting.
|
| To begin using Ajile's MVC support, simply create a .js file with the exact
| name of your (X)HTML, JSP, ASP, PHP, XML, or other page. Next, add the
| following SCRIPT tag to the HEAD section of your page:
| 
| <script type="text/javascript" src="__Ajile's_Path__"></script>
|
| NOTE: Replace the src attribute with an actual path to the Ajile module.
|
| Your script can contain any JavaScript functionality whether specific to your
| page or not. Ajile will automatically load this script whenever your page is
| loaded. It will now be treated as your page's own per-page module.
|
| If your page will be accessed as a default page (no filename specified), i.e:
|
|  http://ajile.iskitz.com/   loads    http://ajile.iskitz.com/index.htm
|
| Ajile will automatically load the index.js per-page module found in your .htm
| file's directory. This module should contain the behavioral logic for your
| default page. If for example you're using IIS configured such that:
|
|  http://ajile.iskitz.com/   loads    http://ajile.iskitz.com/default.htm
|
| your per-page module must still be named "index.js" and NOT default.js. This
| requirement exists because there is currently no standard client-side
| JavaScript technique for determining your page's actual name when it's loaded
| as a default page.
|+----------------------------------------------------------------------------*/

//Ajile.EnableCloaking(false);
//Ajile.EnableDebug(false);
//Ajile.EnableOverride();

Namespace ("com.iskitz.ajile");

Import ("com.iskitz.ajile.examples.*.0.6", "scripts/");
Import ("com.iskitz.ajile.examples.ImportModule.*");


com.iskitz.ajile.Examples = new function()
{
   var areImportsReady = false;
   var linkMap         = { "#Dependence"     :testDependence
                         , "#Import"         :testImport
                         , "#ImportAlias"    :testImportAlias
                         , "#ImportListener" :testImportListener
                         , "#ImportModule"   :testImportModule
                         , "#Load"           :testLoad
                         , "#Namespace"      :testNamespace
                         };

   window.onload   = $Create;
   window.onunload = $Destroy;
   Ajile.AddImportListener(onAnyImport);

   
   function $Create()
   {
    //Ajile.ShowLog();

      if(typeof document.links != "undefined")
         for(var links = document.links, i = links.length; --i >= 0;)
            links[i].onclick = handleLink;
   }
   
   function $Destroy()
   {
      if("undefined" == typeof Ajile)
         return;
         
    //Ajile.ShowLog();
      Ajile.Unload("com.iskitz.examples.*");
      Ajile.Unload("com.iskitz.Examples");
   }
   

   function handleLink()
   {
      if(typeof this.hash != "string" || !this.hash || this.hash == '#')
         return true;

      var action = (linkMap[this.hash] || handleLink);
      action();

      return false;
   }

   function onAnyImport(moduleName)
   {
      if(  "undefined" == typeof AComplex
        || "undefined" == typeof Complex
        || "undefined" == typeof ImportFunction
        || "undefined" == typeof showContents
        || "undefined" == typeof com.iskitz.ajile.examples.LoadExample)
         return;

      areImportsReady = true;
      Ajile.RemoveImportListener(onAnyImport);
      $Create();
   }

   function testDependence()
   {
      if("undefined" != typeof Complex)
      {
	      var complex = new Complex();
	      complex.sayHello();
      }
      else alert( "Dependency test was unsuccessful :-(\n\n"
                + "Failed to Import [ com.iskitz.ajile.examples.Complex ]");
   }

   function testImport()
   {
      if("undefined" != typeof ImportFunction)
         ImportFunction();

      else alert( "Import test was unsuccessful :-(\n\n"
                + "Failed to Import [ com.iskitz.ajile.examples.ImportFunction ]");
   }

   function testImportAlias()
   {
      if("undefined" != typeof Complex && "undefined" != typeof AComplex)
      {
         (new Complex() ).sayHello();  // Create & use Complex object.
         (new AComplex()).sayHello();  // Create & use ambiguous Complex object.
      }
      else alert( "Ambiguity test was unsuccessful :-(\n\n"
                + "Failed to import both [ com.iskitz.ajile.examples.Complex ]\n"
                + "and [ com.iskitz.ajile.examples.ambiguous.Complex ]");
   }

   function testImportListener(moduleName)
   {
      var status = areImportsReady ? ' ' : " NOT ";

      alert( "Import Listener test was" + status +"successful!\n\n"
           + "All required modules have"+ status +"been imported.");
   }

   function testImportModule()
   {
      // Test if showContents method has been imported.
      var imported = "undefined" != typeof showContents;

      if(imported)// Test if imported showContents is ImportModule.showContents.
         if("undefined" != typeof com.iskitz.ajile.examples.ImportModule)
            if(showContents == com.iskitz.ajile.examples.ImportModule.showContents)
               imported = true;
      
      if(imported) showContents();

      else alert( "ImportModule test was unsuccessful :-(\n\n Failed to "
                + "Import [ com.iskitz.ajile.examples.ImportModule.* ]");
   }

   function testLoad()
   {
      if("undefined" != typeof com.iskitz.ajile.examples)
         if("undefined" != typeof com.iskitz.ajile.examples.LoadExample)
            com.iskitz.ajile.examples.LoadExample();

         else alert( "Load test was unsuccessful :-(\n\n"
                   + "Failed to Load [ com.iskitz.ajile.examples.LoadExample.js ]");
   }

   function testNamespace()
   {
      Namespace ("com.iskitz.ajile.examples");

      var msg = typeof com.iskitz.ajile.examples == "undefined"
              ? "Failed to create"
              : "Successfully created";

      alert(msg + " the [ com.iskitz.ajile.examples ] namespace!");
   }
};