JSPackaging Framework
Copyright (c) 2003 Michael Lee, iskitz@users.sourceforge.net, All rights reserved.

URL: http://jspackaging.sourceforge.net/

--------------------------------------------------------------------------------
Description
--------------------------------------------------------------------------------
The JSPackaging Framework is an elegant solution created to provide JavaScript
developers with Well-defined Data & Functionality Encapsulation, clear
Dependency Definition, and Simplified External Script loading.


--------------------------------------------------------------------------------
Thanks
--------------------------------------------------------------------------------
Thanks for using JSPackaging. Feel free to email me with suggestions and/or
information on how you're using it within your own creations.
                                                                -Michael


--------------------------------------------------------------------------------
Limitations
--------------------------------------------------------------------------------
Tested with:
- Internet Explorer 6.0
- Mozilla 1.4
- Mozilla Firebird 0.7

Requires:
- JavaScript 1.4+
- ECMA-262, Edition 3+
- JScript 5.0+


--------------------------------------------------------------------------------
Components
--------------------------------------------------------------------------------
- com.iskitz.js.packaging.JSImport
- com.iskitz.js.packaging.JSLoad
- com.iskitz.js.packaging.JSPackage

See Help.txt for detailed information.


--------------------------------------------------------------------------------
Usage
--------------------------------------------------------------------------------
- Load into your webpage as follows:
     <script type="text/javascript"
             src="<scripts directory>/com/iskitz/js/packaging/packaging.js">
     </script>

- Use within other .js files or inline JavaScript as follows:

     JSPackage("com.company.package");
     JSImport("com.company.package.subpackage.*");

     com.company.package.YourObject = <your object definition here>;


--------------------------------------------------------------------------------
Known Issues
--------------------------------------------------------------------------------
1. Usage can generate undefined property warnings when Strict JavaScript is
   enabled (javascript.options.strict=true) in Mozilla Firebird.

2. JavaScript objects that declare membership in a package via a
   JSPackage("com.company.package") statement must explicitly load all
   referenced package objects via either a
   JSImport("com.company.package.Object" [, Option path]) statement, a
   JSImport("com.company.package.*") statement, or a standard HTML
   <script> tag in the HTML page within which the script is defined.

