/*-----------------------------------------------------------------------------+
| Author:      Michael A. I. Lee             [ http://ajile.iskitz.com/ ]
| Created:     Tuesday,  September 12, 2006 [2006.09.12]
| Modified:    Thursday, November 8, 2007 [2007.11.08]
|+-----------------------------------------------------------------------------+
|
| Description: A JavaScript module that demonstrates using Ajile with the Google
|              Maps API. This module is based on the Google Maps API version 2's
|              "Hello, World" example.
|+-----------------------------------------------------------------------------+
|
|           Visit http://ajile.iskitz.com/ to start creating
|
|                  "Smart scripts that play nice!"
|
|           Copyright (c) 2003-2008 Michael A. I. Lee, iSkitz.com
|
|+----------------------------------------------------------------------------*/

Namespace("com.iskitz.ajile.tests");

com.iskitz.ajile.tests.SimpleGoogleMap = new function()
{
   function load(moduleName)
   {
      if(  typeof GMap2   == "undefined"
        || typeof GLatLng == "undefined"
        || !GBrowserIsCompatible())
        return;

      Ajile.RemoveImportListener(arguments.callee);

      var map = new GMap2(document.getElementById("map"));
      map.setCenter(new GLatLng(40.742575,-73.911209), 11);
   }
   
   Ajile.AddImportListener((this.load = load));

   window.onunload = function()
   {
      Ajile.Unload();

      if(typeof GUnload != "undefined")
         GUnload();
   };
};

Load( "http://maps.google.com/maps?file=api&v=2.x"
    + "&async=2&callback=com.iskitz.ajile.tests.SimpleGoogleMap.load"
    + "&key=GOOGLE_MAPS_API_KEY_HERE"
    );