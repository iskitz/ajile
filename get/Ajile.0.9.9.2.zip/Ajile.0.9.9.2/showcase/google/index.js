/*-----------------------------------------------------------------------------+
| Author:      Michael A. I. Lee            [ajile@iskitz.com]
| Created:     Saturday, September 23, 2006 [2006.09.23]
|+-----------------------------------------------------------------------------+
|
| Description: A JavaScript module that demonstrates using Ajile with the Google
|              Maps API. This module is based on the Google Maps API version 2's
|              "Hello, World" example.

| Note:        For reasons currently unknown the Google Maps API version 2
|              must be loaded via a script tag in the HTML page. In addition the
|              Google Maps API script tag must exist before Ajile's script tag.
|              Reversing the order causes unexpexted behavior from both modules.
|+-----------------------------------------------------------------------------+
|
|           Visit http://ajile.iskitz.com/ to start creating
|
|                  "Smart scripts that play nice!"
|
|           Copyright (c) 2003-2006 Michael A. I. Lee, iSkitz.com
|
|+----------------------------------------------------------------------------*/

Namespace("com.iskitz.ajile.tests");

com.iskitz.ajile.tests.SimpleGoogleMap = new function()
{
   function shutdown()
   {
      Ajile.Unload();

      if(typeof GUnload != "undefined")
         GUnload();
   }

   function startup(e)
   {
      if(  typeof GMap2   == "undefined"
        || typeof GLatLng == "undefined"
        || !GBrowserIsCompatible())
        return;

      var map = new GMap2(document.getElementById("map"));
      map.setCenter(new GLatLng(40.742575,-73.911209), 11);
   }

   window.onload   = startup;
   window.onunload = shutdown;
};