JSPackage ("com.iskitz.js.packaging.examples");

com.iskitz.js.packaging.examples.JSImportExample = function ()
{
   alert("JSImportExample was successfully imported!");
};