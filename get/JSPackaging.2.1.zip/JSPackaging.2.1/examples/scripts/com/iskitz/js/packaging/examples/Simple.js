JSPackage ("com.iskitz.js.packaging.examples");

com.iskitz.js.packaging.examples.Simple = function()
{
	this.toString = function toString()
	{
		return "[Simple]";
	};
};