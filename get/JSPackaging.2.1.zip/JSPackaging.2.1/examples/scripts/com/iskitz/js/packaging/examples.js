JSPackage ("com.iskitz.js.packaging.examples");

JSImport ("com.iskitz.js.packaging.examples.Complex");
JSImport ("com.iskitz.js.packaging.examples.JSImportExample");
JSImport ("com.iskitz.js.packaging.examples.JSLoadExample");
