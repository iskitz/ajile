window.onload = function ()
{
   JSImport ("com.iskitz.js.packaging.examples.JSImportExample");
   JSImport ("com.iskitz.js.packaging.examples.Complex");
   JSLoad ("scripts/com/iskitz/js/packaging/examples/JSLoadExample.js");
};

function testJSImport()
{
   if(typeof JSImportExample != "undefined")
      JSImportExample();
   else
      alert("com.iskitz.js.packaging.examples.JSImportExample\n"
            + "was NOT successfully imported");
   
   return false;
}

function testJSLoad()
{
   if(typeof isJSLoaded != "undefined")
      isJSLoaded();
   else
   {
      alert("Failed to load com/iskitz/js/packaging/examples/JSLoadExample.js "
            + "external JavaScript file!");
   }
   
   return false;
}

function testJSPackage()
{
   // create com.iskitz.js.packaging.examples package
   JSPackage ("com.iskitz.js.packaging.examples");
      
   var status = "NOT";

   if(com != undefined)
      if(com.iskitz != undefined)
         if(com.iskitz.js.packaging != undefined)
            if(com.iskitz.js.packaging.examples != undefined)
               status = "successfully";

   alert("The com.iskitz.js.packaging.examples package\n"
         + "was [ " + status + " ] created!");
   
   return false;
}
   
function testPackageDependency()
{
   var complex = new Complex();
   complex.sayHello();
   
   return false;
}
