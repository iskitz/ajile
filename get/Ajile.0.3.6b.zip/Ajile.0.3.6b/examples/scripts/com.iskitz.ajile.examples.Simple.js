Package ("com.iskitz.ajile.examples");

com.iskitz.ajile.examples.Simple = function()
{
	this.toString = function toString()
	{
		return "[Simple]";
	};
};