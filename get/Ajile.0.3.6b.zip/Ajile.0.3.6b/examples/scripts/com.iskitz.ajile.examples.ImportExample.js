Package ("com.iskitz.ajile.examples");

com.iskitz.ajile.examples.ImportExample = function ()
{
   alert("ImportExample was successfully imported!");
};