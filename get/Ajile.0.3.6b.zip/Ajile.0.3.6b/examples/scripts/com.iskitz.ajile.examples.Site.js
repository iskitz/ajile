Package ("com.iskitz.ajile.examples");

Import ("com.iskitz.ajile.examples.Complex");
Import ("com.iskitz.ajile.examples.ImportExample");
Load   ("scripts/com.iskitz.ajile.examples.LoadExample.js");

com.iskitz.ajile.examples.Site = new function()
{
   this.testImport = function testImport()
   {
      if(typeof ImportExample != "undefined")
         ImportExample();
      else
         alert("com.iskitz.ajile.examples.ImportExample\n"
               + "was NOT successfully imported");

      return false;
   };

   this.testLoad = function testLoad()
   {
      if(typeof isLoaded != "undefined")
         isLoaded();
      else
      {
         alert("Failed to load com.iskitz.ajile.examples.LoadExample.js "
               + "external JavaScript file!");
      }

      return false;
   };

   this.testPackage = function testPackage()
   {
      // create com.iskitz.ajile.examples package
      Package ("com.iskitz.ajile.examples");

      var status = "NOT";

      if(com != undefined)
         if(com.iskitz != undefined)
            if(com.iskitz.ajile != undefined)
               if(com.iskitz.ajile.examples != undefined)
                  status = "successfully";

      alert("The com.iskitz.ajile.examples package\n"
            + "was [ " + status + " ] created!");

      return false;
   };

   this.testPackageDependency = function testPackageDependency()
   {
      var complex = new Complex();
      complex.sayHello();

      return false;
   };
};

Import ("com.iskitz.ajile.examples.Site");
