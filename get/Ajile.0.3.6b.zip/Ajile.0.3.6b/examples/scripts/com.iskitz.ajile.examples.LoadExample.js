function isLoaded()
{
   alert("Load was successful!");
}

