/*-----------------------------------------------------------------------------+
| Product:  com.iskitz.js.dom.events.EventTarget
|+-----------------------------------------------------------------------------+
| Author:   Michael A. I. Lee <iskitzdev@yahoo.com>
| Created:  Thursday, May       12, 2005
| Modified: Friday,   September 16, 2005, 05:44:44 EST
| Version:  0.2
|+-----------------------------------------------------------------------------+
| To Do:
| + .
*-----------------------------------------------------------------------------*/

Package ("com.iskitz.js.dom.events");

Import  ("com.iskitz.js.dom.events.EventException");
Import  ("com.iskitz.js.util.Collection");

com.iskitz.js.dom.events.EventTarget = function(target)
{
   if(!target) target = this;

   // Skip creating custom event listeners if com.iskitz.js.util.Collection
   // has not been loaded or target is already compliant with W3C DOM2 Events.
   if(!com.iskitz.js.util.Collection
      || (target.addEventListener && target.removeEventListener))
      return;

   var listeners        = {}
       , listenersVIP   = {}
       , tempListener;


   function createBaseListener(type)
   {
      target[type] = handleEvent;
   }

   function handleEvent(e)
   {
      // Make event implementation ambiguous
      var type = "on" + (e = e || event).type;

      // Store this base event listener for later reassignment
      var baseEventListener = target[type];

      var allListeners = [listeners[type], listenersVIP[type]];

      // Notify all listeners, starting with those that useCapture
      for(var iterator, i=allListeners.length; --i >= 0;)
      {
         if(!allListeners[i]) continue;

         iterator = allListeners[i].iterator();

         if(!iterator) continue;

         for(var listener; iterator.hasNext();)
         {
            listener = iterator.next();

            if(!listener || listener.constructor != Function)
               continue;

            // Remap base event listener to actual event handler to support
            // actual handler's "this" references.
            target[type] = listener;
            logListener("doing",target,type,listener);
            target[type](e);

            // Restore the base event listener
            target[type] = baseEventListener;
         }
      }

      return true;
   }

   target.addEventListener = function addEventListener(type, listener, useCapture)
   {
      if(!(type && listener)) return;

      type = "on" + type;

      // check if this listener type has already been added
      if(!(listeners[type] || listenersVIP[type]))
      {
         // check for pre-existing listener
         if(this[type])
         {
            // create listeners collection if necessary
            if(!listeners[type])
               listeners[type] = new com.iskitz.js.util.Collection();

            // store pre-existing listener in listeners list
            listeners[type].add(this[type]);
         }

         createBaseListener(type);
      }

      tempListener = useCapture ? listenersVIP : listeners;

      if(!tempListener[type])
         tempListener[type] = new com.iskitz.js.util.Collection();

         // don't re-add if listener was already added
         if(tempListener[type].contains(listener))
            return;

      // add listener to listener list
      tempListener[type].add(listener);

      logListener("added", target, type, listener);
   };

   // Performs clean-up, re-using any pre-existing destroy method in the target
   var _destroy = target.destroy;
   target.destroy = function destroy()
   {
      listeners = listenersVIP = tempListener = undefined;

      if(typeof _destroy == "function")
         _destroy();
   };

   // Causes the specified event to be triggered for all registered listeners
   target.dispatchEvent = function dispatchEvent(e)
   {
      if(!e) return true;

      if(!e.type)
         throw new EventException();

      var type = "on" + e.type;

      if(typeof this[type] == "function")
         this[type](e);

      return true;
   };

   target.removeEventListener = function removeEventListener(type, listener, useCapture)
   {
      if(!type) return;

      type = "on" + type;

      tempListener = useCapture ? listenersVIP : listeners;

      if(!tempListener[type])
         return;

      tempListener[type].remove(listener);
      logListener("removed",target,type,listener);
   };

   var prevMessages = '';
   function logListener(action,target,type,listener)
   {
      if(typeof Logger == "undefined") return;

      var re = /function\s+(\w+)\(/;
      var id = target.getId ? target.getId() : target.id;

      var msg = "\n"+action.toUpperCase()+" ["+id+'.'
                +type+"\t="+(re.exec(listener.toString())[1])+"]";

      if(typeof Logger != "undefined")
      {
         msg = prevMessages + msg;
         Logger.log(msg.replace(/\n/gi,"<br>"));
         prevMessages = '';
      }
      else
      {
         prevMessages += msg;
         //alert(prevMessages);
      }
   }
};