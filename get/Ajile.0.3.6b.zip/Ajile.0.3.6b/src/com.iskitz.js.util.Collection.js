// TODO: Use instanceof to test for correct type

/*-----------------------------------------------------------------------------+
| Product:  com.iskitz.js.util.Collection
|          (c) 2003 Michael Lee, iSkitz.com, All rights reserved.
|+-----------------------------------------------------------------------------+
| Author:   Michael A. I. Lee <iskitz@yahoo.com>
| Created:  November 5th, 2003 [2003.11.05]
|+-----------------------------------------------------------------------------+
| This is the JavaScript equivalent of the Java's java.util.Collection.
*-----------------------------------------------------------------------------*/


Package ("com.iskitz.js.util");

Import ("com.iskitz.js.util.Iterator");


com.iskitz.js.util.Collection = function (/* Array */ members, /* boolean */ copy)
{
   this.add = function add(/* Object */ object)
   {
      var _length = _members.length;
      _members[_members.length] = object;

      return _length < _members.length;
   };


   this.addAll = function addAll(/* Collection */ object)
   {
      if(object == undefined) throw "Cannot add from undefined object!";

      var _isArray = object.constructor == Array;
      var _isCollection = object.constructor == com.iskitz.js.util.Collection;
      var _length = _members.length;

      if(_isArray)
          _addArray(object);
      else if(_isCollection)
         _addCollection(object);
      else throw "Invalid object type! Requires Array or Collection";

      return _length < _members.length;
   };


   this.clear = function clear()
   {
      return _members = [];
   };


   this.contains = function contains(/* Object */ object)
   {
      return _indexOf(object) >= 0;
   };


   this.containsAll = function containsAll(/* Collection */ object)
   {
      var _object = object.toArray();

      for(var i=_object.length; --i >= 0;)
         if(!this.contains(_object[i]))
            return false;

      return true;
   };


   this.isEmpty = function isEmpty()
   {
      return _members.length == 0;
   };


   this.iterator = function iterator()
   {
      return (typeof Iterator == "undefined")
             ? new com.iskitz.js.util.Iterator(this)
             : new Iterator(this);
   };


   this.remove = function remove(/* Object */ object)
   {
      var i = _indexOf(object);

      if(i == -1) return false;

      _members[i] = undefined;

      for(var j=_members.length-1; i < j; i++)
         _members[i] == _members[i+1];

      _members.length--;

      return true;
   };


   this.removeAll = function removeAll(/* Collection */ object)
   {
      var _length = _members.length;
      var _object = object.toArray();

      for(var i=_object.length; --i >= 0;)
         this.remove(_object[i]);

      return _length > _members.length;
   };


   this.size = function size()
   {
      return _members.length;
   };


   this.toArray = function toArray()
   {
      var _arrayCopy = [];

      for(var i=0, j=_members.length; i < j; i++)
         _arrayCopy[i] = _members[i];

      return _arrayCopy;
   };


   this.toString = function toString()
   {
      var _output = _members.length > 0 ? "[" : "[object com.iskitz.js.util.Collection";
      var _end = _members.length - 1;

      for(var i=0; i < _members.length; i++)
      {
         _output += '' + eval(_members[i]);
         if(i < _end) _output += ', ';
      }

      return _output + "]\n";
   };


   /*--------------------------------------------------------------------------+
   | Private variables and functions.
   *--------------------------------------------------------------------------*/


   var _members = [];

   if(members != undefined)
      if(copy == undefined || !copy)
         _members = members;
      else this.add(members);


   var _addArray = function _addArray(/* Array */ array)
   {
      for(var i=0; i < array.length; i++)
         _members[_members.length] = array[i];
   };

   var _addCollection = function _addCollection(/* Collection */ collection)
   {
      var _collection = collection.toArray();

      for(var i=0, j=_collection.length; i < j; i++)
         _members[_members.length] = _collection[i];
   };


   var _indexOf = function _indexOf(/* Object */ object)
   {
      for(var i=0; i < _members.length; i++)
         if(_members[i] == object)
            return i;

      return -1;
   };
};
