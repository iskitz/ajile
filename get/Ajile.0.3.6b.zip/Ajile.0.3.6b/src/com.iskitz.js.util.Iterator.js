// TODO: Use instanceof to test for correct type


/*-----------------------------------------------------------------------------+
| Product:  com.iskitz.js.util.Iterator
|          (c) 2003 Michael Lee, iSkitz.com, All rights reserved.
|+-----------------------------------------------------------------------------+
| Author:   Michael A. I. Lee <iskitz@yahoo.com>
| Created:  November 5th, 2003 [2003.11.05]
|+-----------------------------------------------------------------------------+
| This is the JavaScript equivalent of the Java's java.util.Iterator.
*-----------------------------------------------------------------------------*/


Package ("com.iskitz.js.util");

Import  ("com.iskitz.js.util.Collection");


com.iskitz.js.util.Iterator = function (/* Collection */ object)
{
   if(!object || object.constructor != Collection || !(object instanceof Collection))
      throw "Invalid Collection object";

   var _object = object.toArray();
   var _index = 0;


   this.hasNext = function hasNext()
   {
      return _index < _object.length;
   };


   this.next = function next()
   {
      return _object[_index++];
   };


   this.remove = function remove()
   {
      object.remove(_object[_index]);
   };


   this.toString = function toString()
   {
      return "[object com.iskitz.js.util.Iterator]";
   };
};