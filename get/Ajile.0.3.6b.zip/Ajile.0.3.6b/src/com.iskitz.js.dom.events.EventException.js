/*-----------------------------------------------------------------------------+
| Product:  com.iskitz.js.dom.events.EventException
|+-----------------------------------------------------------------------------+
| Author:   Michael A. I. Lee <iskitzdev@yahoo.com>
| Created:  Thursday, May      12, 2005
| Modified: Saturday, June     04, 2005, 15:52:14 EST
| Version:  1.0
|+-----------------------------------------------------------------------------+
| To Do:
| +
*-----------------------------------------------------------------------------*/

Package ("com.iskitz.js.dom.events");

com.iskitz.js.dom.events.EventException = function()
{
   // Class Constructor - Defines public class members
   function EventException()
   {
      var Class = com.iskitz.js.dom.events.EventException.prototype;

      /*const unsigned short*/   Class.UNSPECIFIED_EVENT_TYPE_ERR = 0;

      Class.getClass = function getClass()
      {
         return Class;
      };
   }

   // Invoke class constructor only once
   if(!com.iskitz.js.dom.events.EventException.prototype.getClass)
      EventException();


   this.toString = function toString()
   {
      var gotMatch = false;
      var code = 0;

      for(var exceptionCode in this)
         if(this[exceptionCode] == code)
         {
            gotMatch = true;
            break;
         }

      return "EventException: " + gotMatch ? (exceptionCode + " = ")
                                          : "Unknown exception - "
                                + code
                                + " :: Event type must be initialized before dispatching!";
   };
};