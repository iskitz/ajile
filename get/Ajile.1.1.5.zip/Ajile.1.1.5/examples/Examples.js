/**----------------------------------------------------------------------------+
| Product:  Examples.js - Ajile's Examples page Controller Module.             |
|+-----------------------------------------------------------------------------+
| Author:   Michael A. I. Lee [ http://ajile.iskitz.com/ ]
|
| Created:  Friday,    November   2, 2006    [2006.06.02 - 07:44:40 PM EDT]
| Modified: Monday,    December  24, 2007    [2007.12.24 - 02:54:08 PM EDT]
|+-----------------------------------------------------------------------------+
|
|   [ Ajile :: http://ajile.iskitz.com/ :: "Smart scripts that play nice!" ]
| 
| This module is a functional example of Ajile's Model View Controller (MVC)
* support feature. This Examples.js module actually supports the Examples.htm
* page's functinality. If you take the time to look, you'll see that there is no
* JavaScript code within the Examples.htm page except for Ajile's script tag:
| 
|  <script type="text/javascript" src="path/to/com.iskitz.ajile.js"></script>
|
* Ajile's MVC support makes it possible to completely separate a page's
| presentation [(X)HTML] and behavioral (JavaScript) layers by creating a
* single point of control for scripting.
|
| To begin using Ajile's MVC support, simply create a .js file with the exact
| name of your (X)HTML, JSP, ASP, PHP, XML, or other page. Then, add the
| Ajile SCRIPT tag shown above to your page.
|
| NOTE: Be sure to update Ajile's path to point to your copy! ;-)
|
| Your custom controller script (i.e. MyPage.js for MyPage.htm) can contain any
* JavaScript functionality, page related or not. Ajile will automatically load
* this script whenever your page is requested. It will now be treated as your
* page's controller module.
|
| If your page will be accessed as a default page (no filename specified), i.e:
|
|  http://ajile.iskitz.com/   loads    http://ajile.iskitz.com/index.htm
|
| Ajile will automatically load the index.js module from your page's directory.
* This is typically the file you should consider usinsg to define implement your
* GUI control logic.
* 
* NOTE: If for example you're using IIS configured such that:
|
|  http://ajile.iskitz.com/   loads    http://ajile.iskitz.com/default.htm
|
| There are 2 choices to guarantee Ajile's MVC functionality:
* 
* 1: Name your controller module "index.js".
* 
* 2: Copy the index.js file and rename it to your server's default page
*    (i.e. IIS uses default.htm so rename your index.js copy to default.js)
|+----------------------------------------------------------------------------*/

// Runtime option setting examples:
//
// Ajile.EnableCloak(false);     // Hides source code from DOM at runtime.
// Ajile.EnableDebug(/*false*/); // Enables/disables debug logging. 
// Ajile.EnableOverride();       // Enables/disables namespace/module overwriting.

// Define this module's namespace.
Namespace ("com.iskitz.ajile");

// Include all members of the examples package version 0.9.
Include ("com.iskitz.ajile.examples.*.0.9", "scripts/");

// Define the Examples module
com.iskitz.ajile.Examples = new function()
{
   var linkMap;

   // Begin using this Examples page module.
   function $begin()
   {
      window.onload   = initialize;// Initialize the Examples page once loaded.
      window.onunload = $end;      // End use of this Examples page module.

      // Unobtrusive HTML & JS:
      // This is a map between the links in the Examples page and the JavaScript
      // functions that support those linked examples. Using simple HTML anchors
      // allows easy unobtrusive mapping, removing all JS from the HTML page!
      linkMap = { "Dependence"     :testDependence
                , "Import"         :testImport
                , "ImportAlias"    :testImportAlias
                , "ImportListener" :testImportListener
                , "ImportModule"   :testImportModule
                , "Include"        :testInclude
                , "Load"           :testLoad
                , "Namespace"      :testNamespace
                };

      // Add listener to observe any import/include events.
      Ajile.AddImportListener(isPageReady);

      if(typeof document.parentNode != "undefined")
      {  // Include and use Alex Gorbatchev's Syntax Highlighter if this host
         // environment supports parentNode. parentNode is the most advanced DOM
         // property used by Syntax Highlighter, so let's only include the
         // library if the environment supports it.

         Include ("dp.sh.Brushes.JScript.1.5.1", "../lib/highlight/");

         // Let's add an an include listener so we know when it's ready
         Ajile.AddImportListener("dp.sh.Brushes.JScript", function(moduleName)
         {  
            Ajile.RemoveImportListener(moduleName, arguments.callee);
            dp.sh.HighlightAll("code");
         });
      }
   }
   
   
   // Ends use of this Examples page module by unloading all resources it
   // created and /or acquired since we began using it.
   function $end()
   {
      // Reset all modified links
      if(typeof document.links != "undefined")
         for(var link, links = document.links, i = links.length; --i >= 0;)
            if(linkMap[(link = links[i]).name])
               link.href = '#' + link.name;

      // Release the link map
      for(var item in linkMap)
         delete linkMap[item];
      linkMap = null;
         
      if(typeof Ajile == "undefined") return;

      //Ajile.ShowLog();
      Ajile.Unload("com.iskitz.ajile.examples.*"); // Release examples package.
      Ajile.Unload("dp.sh.*");                     // Release Syntax Highlighter.
      Ajile.Unload("com.iskitz.ajile.Examples");   // Release this module.
   }


   // Initialize the Examples page by specifically mapping relevant links to
   // their corresponding test functions.
   function initialize()
   {
      if(typeof document.links != "undefined")
         for(var link, links = document.links, i = links.length; --i >= 0;)
            if(linkMap[(link = links[i]).name])
               link.href = 'javascript:com.iskitz.ajile.Examples("'+ link.name +'")';
      
      // Publish the link interceptor using this module's fully qualified name.
      com.iskitz.ajile.Examples = run;
 
    //Ajile.ShowLog();
   }

   // ImportListener that triggers the Examples page's initialization once all
   // required modules are ready for use.
   function isPageReady(moduleName)
   {
      if(  "undefined" == typeof AComplex
        || "undefined" == typeof Complex
        || "undefined" == typeof ImportFunction
        || "undefined" == typeof showContents
        || "undefined" == typeof com.iskitz.ajile.examples.LoadExample)
         return;

      Ajile.RemoveImportListener(isPageReady);
      isPageReady = true;
      initialize();
   }
   

   function run(example)
   {
      if(!example) return;

      var runExample = linkMap[example];
      if (runExample)  runExample();
   }


   // Tests Ajile's dependency enforcement feature; see com.iskitz.examples.0.9.js
   function testDependence()
   {
      if("undefined" != typeof Complex)
      {
	      var complex = new Complex();
	      complex.sayHello();
      }
      else alert( "Dependency test was unsuccessful :-(\n\n"
                + "Failed to Import [ com.iskitz.ajile.examples.Complex ]");
   }

   // Tests Ajile's import feature; see com.iskitz.examples.0.9.js
   function testImport()
   {
      if("undefined" != typeof ImportFunction)
         ImportFunction();

      else alert( "Import test was unsuccessful :-(\n\n"
                + "Failed to Import [ com.iskitz.ajile.examples.ImportFunction ]");
   }

   // Tests Ajile's aliased-import feature; see scripts/com.iskitz.examples.0.9.js
   function testImportAlias()
   {
      if("undefined" != typeof Complex && "undefined" != typeof AComplex)
      {
         (new Complex() ).sayHello();  // Create & use Complex object.
         (new AComplex()).sayHello();  // Create & use ambiguous Complex object.
      }
      else alert( "Ambiguity test was unsuccessful :-(\n\n"
                + "Failed to import both [ com.iskitz.ajile.examples.Complex ]\n"
                + "and [ com.iskitz.ajile.examples.ambiguous.Complex ]");
   }

   // Tests Ajile's import listener feature; see scripts/com.iskitz.examples.0.9.js
   function testImportListener()
   {
      var status = isPageReady == true ? ' ' : " NOT ";

      alert( "Import Listener test was" + status +"successful!\n\n"
           + "All required modules have"+ status +"been imported.");
   }

   // Tests Ajile's module member import feature; see scripts/com.iskitz.examples.0.9.js
   function testImportModule()
   {
      // Test if showContents method has been imported.
      var imported = "undefined" != typeof showContents;

      if(imported)// Test if imported showContents is ImportModule.showContents.
         if("undefined" != typeof com.iskitz.ajile.examples.ImportModule)
            if(showContents == com.iskitz.ajile.examples.ImportModule.showContents)
               imported = true;
      
      if(imported) showContents();

      else alert( "ImportModule test was unsuccessful :-(\n\n Failed to "
                + "Import [ com.iskitz.ajile.examples.ImportModule.* ]");
   }

   // Tests Ajile's include feature; see scripts/com.iskitz.examples.0.9.js
   function testInclude()
   {
      if("undefined" != typeof com.iskitz.ajile.examples)
         if("undefined" != typeof com.iskitz.ajile.examples.IncludeExample)
            com.iskitz.ajile.examples.IncludeExample();

         else alert( "Include test was unsuccessful :-(\n\n"
                   + "Failed to Include [ com.iskitz.ajile.examples.IncludeExample.js ]");
   }

   // Tests Ajile's load feature; see scripts/com.iskitz.examples.0.9.js
   function testLoad()
   {
      if(  "undefined" != typeof com.iskitz.ajile.examples
        && "undefined" != typeof com.iskitz.ajile.examples.LoadExample)
            com.iskitz.ajile.examples.LoadExample();

      else alert( "Load test was unsuccessful :-(\n\n"
                + "Failed to Load [ com.iskitz.ajile.examples.LoadExample.js ]");
   }

   // Tests Ajile's namespace feature; see scripts/com.iskitz.examples.0.9.js
   function testNamespace()
   {
      Namespace ("com.iskitz.ajile.examples");

      var msg = typeof com.iskitz.ajile.examples == "undefined"
              ? "Failed to create"
              : "Successfully created";

      alert(msg + " the [ com.iskitz.ajile.examples ] namespace!");
   }

   // Begin using this Examples page module! 
   $begin();
};