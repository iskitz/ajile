function isJSLoaded()
{
   alert("JSLoad was successful!");
}

