JSPackage ("com.iskitz.jspackaging.examples");

JSImport ("com.iskitz.jspackaging.examples.Complex");
JSImport ("com.iskitz.jspackaging.examples.JSImportExample");
JSImport ("com.iskitz.jspackaging.examples.JSLoadExample");
