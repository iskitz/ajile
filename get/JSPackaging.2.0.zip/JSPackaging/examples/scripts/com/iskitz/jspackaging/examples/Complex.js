JSPackage ("com.iskitz.jspackaging.examples");

JSImport ("com.iskitz.jspackaging.examples.Simple");

com.iskitz.jspackaging.examples.Complex = function()
{
	var simple = new Simple();
	
	this.sayHello = function sayHello()
	{
		var message = "Hello World!\n\nThis is a " + this.toString() + " object"
		              + " that imported and is\nusing a " + simple.toString()
		              + " object!";

      alert(message);
	};

	this.toString = function toString()
	{
		return "[Complex]";
	};
};