/*-----------------------------------------------------------------------------+
| Author:      Michael A. I. Lee            [ http://ajile.iskitz.com/ ]
| Created:     Tuesday,  September 12, 2006 [2006.09.12]
| Modified:    Thursday, September 28, 2006 [2006.09.28]
|+-----------------------------------------------------------------------------+
|
| Description: A JavaScript module that demonstrates using Ajile with the Google
|              Maps API. This module is based on the Google Maps API version 2's
|              "Hello, World" example.
|
|              To use this sample, replace GOOGLE_MAPS_API_KEY_HERE in the
|              accompanying index.htm with your own Google MAPs API Key.
|
| Note:        For reasons currently unknown the Google Maps API version 2
|              must be loaded via a script tag in the HTML page. In addition the
|              Google Maps API script tag must exist before Ajile's script tag.
|              Reversing the order causes unexpexted behavior from both modules.
|+-----------------------------------------------------------------------------+
|
|           Visit http://ajile.iskitz.com/ to start creating
|
|                  "Smart scripts that play nice!"
|
|           Copyright (c) 2003-2007 Michael A. I. Lee, iSkitz.com
|
|+----------------------------------------------------------------------------*/

Namespace("com.iskitz.ajile.tests");


com.iskitz.ajile.tests.SimpleGoogleMap = new function()
{
   window.onload   = load;
   window.onunload = unload;

   function load(e)
   {
      if(!GBrowserIsCompatible()) return;

      var map = new GMap2(document.getElementById("map"));
      map.setCenter(new GLatLng(40.742575,-73.911209), 11);
   }

   function unload(e)
   {
      Ajile.Unload();

      if(typeof GUnload != "undefined")
         GUnload();
   }
};