Namespace ("com.iskitz.ajile.examples");

com.iskitz.ajile.examples.ImportExample = function()
{
   alert("Successfully imported [ com.iskitz.ajile.examples.ImportExample ]!");
};
