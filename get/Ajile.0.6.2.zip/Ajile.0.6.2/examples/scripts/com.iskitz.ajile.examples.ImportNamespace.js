// Author:      Michael Lee [ ajile@iskitz.com ]
//
// Created:     2006.07.30
// Modified:    2006.08.01
//
// Description: Example of how to define all of a namespace's members within a
//              single container object for later import like:
//
//              Import("com.iskitz.ajile.examples.ImportNamespace.*");

Namespace ("com.iskitz.ajile.examples.ImportNamespace");


com.iskitz.ajile.examples.ImportNamespace = new function()
{
  this.Module1      = function(){ alert("member 1"); };
  this.Module2      = { member:"member 2" };
  this.Module3      = ["member3"];
  this.Module4      = 1
  this.Module5      = "member 5";
  this.Module6      = (/member 6/);
  this.showContents = showContents;
  var  THIS         = this;
  
  function showContents()
  {
      var contents = '.:{ com.iskitz.ajile.examples.ImportNamespace }:.\n\n';

      alert(contents + THIS.constructor.toString());
  }
};
